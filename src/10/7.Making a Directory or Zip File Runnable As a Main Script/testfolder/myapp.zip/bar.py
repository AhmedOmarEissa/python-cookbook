def bar():
    print('bar')