def grok():
    print('grok')