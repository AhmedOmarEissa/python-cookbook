def spam():
    print('spam')