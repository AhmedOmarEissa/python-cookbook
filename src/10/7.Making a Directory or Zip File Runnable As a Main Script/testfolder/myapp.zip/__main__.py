import spam
import bar
import grok

spam.spam()
grok.grok()
bar.bar()